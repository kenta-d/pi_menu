import json
import math
import os
import subprocess
import sys
import shlex
import glob

from PyQt6.QtCore import QSize, Qt, QPropertyAnimation, QEasingCurve, QRect, pyqtProperty, QTimer
from PyQt6.QtGui import QIcon, QPainter, QPen, QBrush, QRadialGradient, QColor, QFont
from PyQt6.QtWidgets import (QApplication, QPushButton, QVBoxLayout, QWidget, 
                           QDialog, QListWidget, QListWidgetItem, QCheckBox, QGraphicsDropShadowEffect, 
                           QToolTip, QHBoxLayout, QLineEdit, QComboBox, QLabel, QScrollArea, 
                           QStackedWidget, QGridLayout, QProgressBar, QTextEdit)

# インポートエラー対応: 相対インポートと絶対インポートの両方に対応
try:
    from .icon_system import IconSystem
except ImportError:
    # 直接実行時の絶対インポート
    import sys
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from icon_system import IconSystem
if __name__ == "__main__":
    # 直接実行時: スクリプトの親ディレクトリのconfig.jsonを参照
    CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
else:
    # モジュールとして実行時
    CONFIG_FILE = "./config.json"

class ModernButton(QPushButton):
    """モダンなアニメーション付きアイコンボタン"""
    
    def __init__(self, app_info, parent=None):
        super().__init__(parent)
        self.app_info = app_info
        self._scale = 1.0
        self._rotation = 0.0
        self.setFixedSize(90, 90)  # サイズを少し大きく
        self.setup_content()
        self.setup_animation()
        self.setup_shadow()
        self.setup_tooltip()
        self.setup_smooth_transitions()
        
    def setup_content(self):
        """ボタンの内容を設定"""
        icon = self.app_info.get('icon', '❓')
        display_name = self.app_info.get('display_name', self.app_info.get('name', ''))
        
        # アイコン + テキストの組み合わせ
        self.setText(f"{icon}\n{display_name}")
        
    def setup_animation(self):
        """ホバーアニメーションの設定"""
        self.animation = QPropertyAnimation(self, b"scale")
        self.animation.setDuration(200)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        
    def setup_shadow(self):
        """ドロップシャドウ効果"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setOffset(0, 4)
        shadow.setColor(QColor(0, 0, 0, 80))
        self.setGraphicsEffect(shadow)
        
    def setup_tooltip(self):
        """ツールチップを設定"""
        self.setToolTip(self.app_info.get('full_name', self.app_info.get('name', '')))
        
    def get_button_style(self):
        """カテゴリに応じたスタイルを生成（見やすい配色・大きめフォント・シャドウ）"""
        colors = self.app_info['colors']
        normal_color, hover_color = colors
        return f"""
            ModernButton {{
                background: {normal_color};
                border: 2px solid rgba(255, 255, 255, 0.2);
                border-radius: 45px;
                color: #fff;
                font-size: 20px;
                font-weight: bold;
                text-align: center;
                padding: 8px;
                line-height: 1.2;
                text-shadow: 1px 1px 6px #222, 0 0 2px #000;
            }}
            ModernButton:hover {{
                background: {hover_color};
                border: 2px solid rgba(255, 255, 255, 0.4);
                color: #fff;
                text-shadow: 1px 1px 8px #222, 0 0 4px #000;
            }}
            ModernButton:pressed {{
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 rgba(82, 106, 214, 0.9),
                    stop: 1 rgba(98, 55, 142, 0.9));
                border: 2px solid rgba(255, 255, 255, 0.6);
            }}
        """
        
    def setup_smooth_transitions(self):
        """スムーズなトランジション効果を設定"""
        # より滑らかなホバーアニメーション
        self.hover_animation = QPropertyAnimation(self, b"scale")
        self.hover_animation.setDuration(250)
        self.hover_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        
        # クリック時のアニメーション
        self.click_animation = QPropertyAnimation(self, b"scale")
        self.click_animation.setDuration(150)
        self.click_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
    
    @pyqtProperty(float)
    def scale(self):
        return self._scale
        
    @scale.setter
    def scale(self, value):
        self._scale = value
        self.setFixedSize(int(90 * value), int(90 * value))
    
    @pyqtProperty(float)
    def rotation(self):
        return self._rotation
        
    @rotation.setter
    def rotation(self, value):
        self._rotation = value
        # 回転効果の実装（PyQt6では直接的な回転は困難なため、スタイル効果で代替）
        self.update()
        
    def enterEvent(self, event):
        # より滑らかなホバー効果
        self.hover_animation.stop()
        self.hover_animation.setStartValue(self._scale)
        self.hover_animation.setEndValue(1.15)
        self.hover_animation.start()
        super().enterEvent(event)
        
    def leaveEvent(self, event):
        # より滑らかなホバー解除効果
        self.hover_animation.stop()
        self.hover_animation.setStartValue(self._scale)
        self.hover_animation.setEndValue(1.0)
        self.hover_animation.start()
        super().leaveEvent(event)
        
    def mousePressEvent(self, event):
        # クリック時のスケールダウン効果
        self.click_animation.stop()
        self.click_animation.setStartValue(self._scale)
        self.click_animation.setEndValue(0.95)
        self.click_animation.start()
        super().mousePressEvent(event)
        
    def mouseReleaseEvent(self, event):
        # クリック解除時のスケールアップ効果
        self.click_animation.stop()
        self.click_animation.setStartValue(self._scale)
        self.click_animation.setEndValue(1.15 if self.underMouse() else 1.0)
        self.click_animation.start()
        super().mouseReleaseEvent(event)

class FavoriteSettings(QDialog):
    """モダンな設定ダイアログ"""
    
    def __init__(self, config_file, parent=None):
        super().__init__(parent)
        self.config_file = config_file
        self.setWindowTitle("アプリ設定")
        self.setMinimumSize(800, 700)
        self.resize(900, 800)
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.WindowCloseButtonHint)
        self.setModal(True)
        
        # アニメーション効果の準備
        self.fade_animation = QPropertyAnimation(self, b"windowOpacity")
        self.fade_animation.setDuration(300)
        
        self.setup_ui()
        self.apply_modern_style()
        self.load_apps()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)
        
        # タイトル
        title = QPushButton("⚙️ アプリケーション設定")
        title.setEnabled(False)
        title.setFixedHeight(60)
        layout.addWidget(title)
        
        # 検索とフィルター
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 アプリを検索...")
        self.search_input.textChanged.connect(self.filter_apps)
        search_layout.addWidget(self.search_input)
        
        self.category_filter = QComboBox()
        self.category_filter.addItems(["全て", "開発", "ブラウザ", "通信", "クリエイティブ", "ユーティリティ", "ドキュメント"])
        self.category_filter.currentTextChanged.connect(self.filter_apps)
        search_layout.addWidget(self.category_filter)
        layout.addLayout(search_layout)
        
        # 新しいアプリを検索ボタン
        scan_button = QPushButton("🔍 新しいアプリを検索")
        scan_button.setFixedHeight(40)
        scan_button.clicked.connect(self.scan_applications)
        layout.addWidget(scan_button)
        
        # アプリリスト（スクロール可能な領域に変更）
        self.app_list = QListWidget()
        self.app_list.setMinimumHeight(400)
        layout.addWidget(self.app_list)
        
        # ボタンレイアウト
        button_layout = QHBoxLayout()
        
        # 保存ボタン
        save_button = QPushButton("💾 保存")
        save_button.setFixedHeight(50)
        save_button.clicked.connect(self.save_favorites)
        button_layout.addWidget(save_button)
        
        # 保存して閉じるボタン
        save_and_close_button = QPushButton("💾 保存して閉じる")
        save_and_close_button.setFixedHeight(50)
        save_and_close_button.clicked.connect(self.save_and_close)
        button_layout.addWidget(save_and_close_button)
        
        # 閉じるボタン
        close_button = QPushButton("✕ 閉じる")
        close_button.setFixedHeight(50)
        close_button.clicked.connect(self.reject)
        button_layout.addWidget(close_button)
        
        layout.addLayout(button_layout)

    def add_shadow_effect(self):
        """ウィンドウにドロップシャドウ効果を追加"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(30)
        shadow.setColor(QColor(0, 0, 0, 120))
        shadow.setOffset(0, 10)
        self.setGraphicsEffect(shadow)

    def apply_modern_style(self):
        self.setStyleSheet("""
            QDialog {
                background: rgb(25, 30, 40);
                border-radius: 8px;
                border: 2px solid rgba(255, 255, 255, 0.3);
            }
            QPushButton {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 rgba(255, 255, 255, 0.15), stop: 1 rgba(255, 255, 255, 0.08));
                border: 1px solid rgba(255, 255, 255, 0.25);
                border-radius: 14px;
                color: #ffffff;
                font-size: 14px;
                font-weight: 600;
                padding: 10px 18px;
                text-align: center;
            }
            QPushButton:hover {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 rgba(102, 126, 234, 0.4), stop: 1 rgba(118, 75, 162, 0.4));
                border: 1px solid rgba(102, 126, 234, 0.6);
                transform: translateY(-2px);
            }
            QPushButton:pressed {
                background: rgba(102, 126, 234, 0.6);
                transform: translateY(0px);
            }
            QPushButton:disabled {
                background: transparent;
                border: none;
                font-size: 18px;
                font-weight: 700;
                color: #ffffff;
            }
            QListWidget {
                background: rgb(35, 40, 50);
                border: 2px solid rgba(255, 255, 255, 0.2);
                border-radius: 12px;
                color: #ffffff;
                font-size: 15px;
                outline: none;
                padding: 12px;
            }
            QListWidget::item {
                padding: 5px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.05);
                border-radius: 8px;
                margin: 4px;
                background: rgba(255, 255, 255, 0.02);
                min-height: 60px;
            }
            QListWidget::item:hover {
                background: rgba(255, 255, 255, 0.05);
                transform: translateY(-1px);
            }
            QListWidget::item:selected {
                background: rgba(102, 126, 234, 0.3);
                border: 1px solid rgba(102, 126, 234, 0.6);
            }
            QCheckBox {
                color: #ffffff;
                font-size: 15px;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 20px;
                height: 20px;
                border-radius: 4px;
                border: 2px solid rgba(255, 255, 255, 0.4);
                background: transparent;
            }
            QCheckBox::indicator:checked {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 #667eea, stop: 1 #764ba2);
                border-color: #667eea;
            }
            QLineEdit {
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                color: #ffffff;
                font-size: 15px;
                padding: 8px 12px;
                outline: none;
            }
            QLineEdit:focus {
                border: 2px solid rgba(102, 126, 234, 0.8);
                background: rgba(255, 255, 255, 0.18);
                box-shadow: 0 0 10px rgba(102, 126, 234, 0.4);
            }
            QLineEdit::placeholder {
                color: rgba(255, 255, 255, 0.5);
                font-style: italic;
            }
            QComboBox {
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                color: #ffffff;
                font-size: 15px;
                padding: 8px 12px;
                min-width: 120px;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #ffffff;
            }
            QComboBox QAbstractItemView {
                background: rgba(20, 25, 35, 1.0);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                color: #ffffff;
                selection-background-color: rgba(102, 126, 234, 0.8);
            }
        """)

    def load_apps(self):
        self.app_data = []
        
        if not os.path.exists(self.config_file):
            return

        with open(self.config_file, "r", encoding="utf-8") as file:
            data = json.load(file)

        self.app_data = data["apps"]
        self.display_apps()
    
    def display_apps(self):
        """アプリリストを表示（カテゴリカラー付き改良版）"""
        self.app_list.clear()
        
        for app in self.app_data:
            app_info = IconSystem.get_app_info(app['name'])
            icon = app_info['icon']
            # 表示名を使用（.appを削除し、見やすい名前に）
            display_name = app_info.get('display_name', app['name'])
            if display_name.endswith('.app'):
                display_name = display_name[:-4]
            category = app_info['category']
            
            # カテゴリに応じた背景色を取得（より濃い色に変更）
            category_colors = {
                'development': 'rgba(52, 211, 153, 0.6)',    # Green
                'browser': 'rgba(59, 130, 246, 0.6)',        # Blue
                'communication': 'rgba(147, 51, 234, 0.6)',  # Purple
                'creative': 'rgba(249, 115, 22, 0.6)',       # Orange
                'utility': 'rgba(107, 114, 128, 0.6)',       # Gray
                'document': 'rgba(236, 72, 153, 0.6)',       # Pink
                'その他': 'rgba(255, 255, 255, 0.3)'          # Default
            }
            
            bg_color = category_colors.get(category, category_colors['その他'])
            
            # カスタムウィジェットを作成
            widget = QWidget()
            widget_layout = QHBoxLayout(widget)
            widget_layout.setContentsMargins(15, 10, 15, 10)
            widget_layout.setSpacing(20)
            
            # チェックボックス
            checkbox = QCheckBox()
            checkbox.setChecked(app.get("favorite", False))
            checkbox.stateChanged.connect(lambda state, app=app: self.toggle_favorite(app, state))
            widget_layout.addWidget(checkbox)
            
            # アイコンラベル
            icon_label = QLabel(icon)
            icon_label.setStyleSheet("""
                QLabel {
                    color: #ffffff;
                    font-size: 26px;
                    padding: 6px;
                }
            """)
            icon_label.setFixedSize(40, 40)
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            widget_layout.addWidget(icon_label)
            
            # アプリ名ラベル（表示専用）
            app_label = QLabel(display_name)
            app_label.setStyleSheet(f"""
                QLabel {{
                    color: #ffffff;
                    font-size: 16px;
                    font-weight: 600;
                    padding: 12px 20px;
                    background: {bg_color};
                    border-radius: 10px;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    min-width: 300px;
                    min-height: 40px;
                }}
            """)
            widget_layout.addWidget(app_label)
            
            # カテゴリラベル
            category_label = QLabel(f"({category})")
            category_label.setStyleSheet("""
                QLabel {
                    color: rgba(255, 255, 255, 0.9);
                    font-size: 13px;
                    font-weight: 500;
                    padding: 8px 12px;
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 8px;
                    min-height: 40px;
                }
            """)
            widget_layout.addWidget(category_label)
            
            widget_layout.addStretch()
            
            # リストアイテムに追加
            item = QListWidgetItem()
            # アイテムの高さを明示的に設定（文字が見えるように適切なサイズ）
            item.setSizeHint(QSize(widget.sizeHint().width(), 80))
            self.app_list.addItem(item)
            self.app_list.setItemWidget(item, widget)
    
    def filter_apps(self):
        """検索とカテゴリフィルターを適用"""
        search_text = self.search_input.text().lower()
        category_filter = self.category_filter.currentText()
        
        self.app_list.clear()
        
        category_map = {
            "開発": "development", "ブラウザ": "browser", "通信": "communication",
            "クリエイティブ": "creative", "ユーティリティ": "utility", "ドキュメント": "document"
        }
        
        for app in self.app_data:
            app_info = IconSystem.get_app_info(app['name'])
            icon = app_info['icon']
            # 表示名を使用（.appを削除し、見やすい名前に）
            display_name = app_info.get('display_name', app['name'])
            if display_name.endswith('.app'):
                display_name = display_name[:-4]
            category = app_info['category']
            
            # 検索フィルター
            if search_text and search_text not in app['name'].lower():
                continue
                
            # カテゴリフィルター
            if category_filter != "全て":
                if category != category_map.get(category_filter, category_filter.lower()):
                    continue
            
            # カテゴリに応じた背景色を取得（より濃い色に変更）
            category_colors = {
                'development': 'rgba(52, 211, 153, 0.6)',    # Green
                'browser': 'rgba(59, 130, 246, 0.6)',        # Blue
                'communication': 'rgba(147, 51, 234, 0.6)',  # Purple
                'creative': 'rgba(249, 115, 22, 0.6)',       # Orange
                'utility': 'rgba(107, 114, 128, 0.6)',       # Gray
                'document': 'rgba(236, 72, 153, 0.6)',       # Pink
                'その他': 'rgba(255, 255, 255, 0.3)'          # Default
            }
            
            bg_color = category_colors.get(category, category_colors['その他'])
            
            # カスタムウィジェットを作成
            widget = QWidget()
            widget_layout = QHBoxLayout(widget)
            widget_layout.setContentsMargins(15, 10, 15, 10)
            widget_layout.setSpacing(20)
            
            # チェックボックス
            checkbox = QCheckBox()
            checkbox.setChecked(app.get("favorite", False))
            checkbox.stateChanged.connect(lambda state, app=app: self.toggle_favorite(app, state))
            widget_layout.addWidget(checkbox)
            
            # アイコンラベル
            icon_label = QLabel(icon)
            icon_label.setStyleSheet("""
                QLabel {
                    color: #ffffff;
                    font-size: 26px;
                    padding: 6px;
                }
            """)
            icon_label.setFixedSize(40, 40)
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            widget_layout.addWidget(icon_label)
            
            # アプリ名ラベル（表示専用）
            app_label = QLabel(display_name)
            app_label.setStyleSheet(f"""
                QLabel {{
                    color: #ffffff;
                    font-size: 16px;
                    font-weight: 600;
                    padding: 12px 20px;
                    background: {bg_color};
                    border-radius: 10px;
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    min-width: 300px;
                    min-height: 40px;
                }}
            """)
            widget_layout.addWidget(app_label)
            
            # カテゴリラベル
            category_label = QLabel(f"({category})")
            category_label.setStyleSheet("""
                QLabel {
                    color: rgba(255, 255, 255, 0.9);
                    font-size: 13px;
                    font-weight: 500;
                    padding: 8px 12px;
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 8px;
                    min-height: 40px;
                }
            """)
            widget_layout.addWidget(category_label)
            
            widget_layout.addStretch()
            
            # リストアイテムに追加
            item = QListWidgetItem()
            # アイテムの高さを明示的に設定（文字が見えるように適切なサイズ）
            item.setSizeHint(QSize(widget.sizeHint().width(), 80))
            self.app_list.addItem(item)
            self.app_list.setItemWidget(item, widget)
    
    def scan_applications(self):
        """macOSの/Applicationsフォルダをスキャンして新しいアプリを検出"""
        try:
            # 既存のアプリ名を取得
            existing_apps = {app['name'] for app in self.app_data}
            
            # /Applicationsフォルダをスキャン
            app_paths = glob.glob('/Applications/*.app')
            new_apps = []
            
            for app_path in app_paths:
                app_name = os.path.basename(app_path).replace('.app', '')
                
                if app_name not in existing_apps:
                    new_app = {
                        "name": app_name,
                        "command": f"open {app_path}",
                        "icon": "",
                        "favorite": False
                    }
                    new_apps.append(new_app)
            
            if new_apps:
                # 新しいアプリをapp_dataに追加
                self.app_data.extend(new_apps)
                self.display_apps()
                
                # 成功メッセージを表示（簡易的にタイトルを一時変更）
                original_title = self.windowTitle()
                self.setWindowTitle(f"✅ {len(new_apps)}個の新しいアプリを発見")
                QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))
            else:
                # 新しいアプリが見つからない場合
                original_title = self.windowTitle()
                self.setWindowTitle("ℹ️ 新しいアプリは見つかりませんでした")
                QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))
                
        except Exception as e:
            print(f"アプリスキャンエラー: {e}")

    def toggle_favorite(self, app, state):
        app["favorite"] = state == 2
        # 即座に保存してメインウィンドウを更新
        self.save_favorites()

    def save_favorites(self):
        """お気に入り設定とconfig.jsonを保存（アニメーション付き）"""
        try:
            # config.jsonの構造でデータを保存
            # --- アイコン情報を保存前に付与 ---
            for app in self.app_data:
                app_info = IconSystem.get_app_info(app["name"])
                if app_info and "icon" in app_info:
                    app["icon"] = app_info["icon"]
                else:
                    app["icon"] = app.get("icon", "❓")
            data = {"apps": self.app_data}
            
            with open(self.config_file, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=4, ensure_ascii=False)
            
            # 成功メッセージとアニメーション
            original_title = self.windowTitle()
            self.setWindowTitle("💾 保存完了")
            
            # 成功時のフェードアウト効果
            self.fade_animation.setStartValue(1.0)
            self.fade_animation.setEndValue(0.8)
            self.fade_animation.finished.connect(lambda: self.fade_animation.setEndValue(1.0))
            self.fade_animation.finished.connect(lambda: self.fade_animation.start())
            self.fade_animation.start()
            
            # メインウィンドウを即座に更新
            if hasattr(self, 'parent') and self.parent():
                parent = self.parent()
                if hasattr(parent, 'load_favorites'):
                    parent.load_favorites()
                if hasattr(parent, 'create_circle_buttons'):
                    parent.create_circle_buttons()
                if hasattr(parent, 'create_category_layout'):
                    parent.create_category_layout()
            
            QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))
            
        except Exception as e:
            print(f"保存エラー: {e}")
            original_title = self.windowTitle()
            self.setWindowTitle("❌ 保存に失敗しました")
            QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))

    def launch_app_from_settings(self, command, checkbox=None):
        """設定ダイアログからアプリを起動"""
        try:
            # アプリを起動
            if command.startswith("open "):
                command = f'open {shlex.quote(command[5:])}'
                result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
            else:
                result = subprocess.run(command.split(), check=True, capture_output=True, text=True)
            
            # 起動したアプリをお気に入りに追加
            app_name = None
            for app in self.app_data:
                if app['command'] == command or (command.startswith("open ") and app['command'] == command[5:]):
                    app_name = app['name']
                    if not app.get("favorite", False):
                        app["favorite"] = True
                        # チェックボックスをチェック
                        if checkbox:
                            checkbox.setChecked(True)
                        # 設定を保存
                        self.save_favorites()
                    break
            
            # 成功メッセージを表示
            original_title = self.windowTitle()
            if app_name:
                self.setWindowTitle(f"✅ {app_name}を起動し、お気に入りに追加しました")
            else:
                self.setWindowTitle("✅ アプリを起動しました")
            QTimer.singleShot(3000, lambda: self.setWindowTitle(original_title))
            
        except subprocess.CalledProcessError as e:
            print(f"アプリの起動に失敗しました: {e}")
            original_title = self.windowTitle()
            self.setWindowTitle("❌ 起動に失敗しました")
            QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))
        except Exception as e:
            print(f"アプリの起動に失敗しました: {e}")
            original_title = self.windowTitle()
            self.setWindowTitle("❌ エラーが発生しました")
            QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))

    def save_and_close(self):
        """お気に入り設定を保存してダイアログを閉じる"""
        self.save_favorites()
        self.accept()

class PiMenu(QWidget):
    """モダンなPi Menuメインウィンドウ"""
    
    def __init__(self):
        super().__init__()
        self.favorite_buttons = []
        self.favorite_apps = []
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Pi Menu - Modern")
        self.setGeometry(100, 100, 800, 600)
        self.setMinimumSize(600, 450)
        
        # フレームレスウィンドウ
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        self.apply_modern_style()
        self.load_favorites()
        self.create_settings_button()
        
        # ツールチップの設定を改善
        QToolTip.setFont(QFont('Arial', 10))
        
        # ツールチップのスタイル設定
        self.setStyleSheet(self.styleSheet() + """
            QToolTip {
                background-color: rgba(0, 0, 0, 200);
                color: white;
                border: 1px solid white;
                padding: 5px;
                border-radius: 3px;
                font-size: 12px;
            }
        """)
        
        # 最近使用したアプリの履歴を初期化
        self.recent_apps = []

    def apply_modern_style(self):
        """モダンなスタイルを適用"""
        self.setStyleSheet("""
            QWidget {
                background: transparent;
                color: #ffffff;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            }
        """)

    def create_settings_button(self):
        """設定ボタンの作成"""
        self.settings_button = QPushButton("⚙️", self)
        self.settings_button.setFixedSize(50, 50)
        self.settings_button.move(20, 20)
        self.settings_button.clicked.connect(self.open_favorite_settings)
        
        self.settings_button.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.15);
                border: 1px solid rgba(255, 255, 255, 0.3);
                border-radius: 25px;
                color: white;
                font-size: 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: rgba(255, 255, 255, 0.25);
                border: 1px solid rgba(255, 255, 255, 0.5);
                transform: scale(1.05);
            }
            QPushButton:pressed {
                background: rgba(255, 255, 255, 0.2);
            }
        """)
        
        # ドロップシャドウ
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setOffset(0, 3)
        shadow.setColor(QColor(0, 0, 0, 100))
        self.settings_button.setGraphicsEffect(shadow)
    
    

    def open_favorite_settings(self):
        settings = FavoriteSettings(CONFIG_FILE, self)
        # 設定ダイアログを開く前に現在の設定を読み込み
        settings.load_apps()
        if settings.exec():
            self.load_favorites()
            self.create_circle_buttons()

    def load_favorites(self):
        """お気に入りアプリを読み込み（カテゴリ別にソート）"""
        self.favorite_apps = []
        
        if not os.path.exists(CONFIG_FILE):
            print("Config file not found:", CONFIG_FILE)
            return

        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as file:
                data = json.load(file)

            # お気に入りアプリを抽出
            favorite_apps = [app for app in data["apps"] if app.get("favorite", False)]
            
            # カテゴリ別にソート
            self.favorite_apps = sorted(favorite_apps, key=lambda app: IconSystem.get_app_category(app['name']))
            
            print(f"Loaded {len(self.favorite_apps)} favorite apps:")
            for app in self.favorite_apps:
                category = IconSystem.get_app_category(app['name'])
                print(f"  - {app['name']} (category: {category})")
                
        except Exception as e:
            print(f"Error loading favorites: {e}")
            self.favorite_apps = []

    def create_circle_buttons(self):
        """円形レイアウトでボタンを配置（カテゴリ別にグループ化）"""
        # 既存のボタンを削除
        for btn in self.favorite_buttons:
            btn.deleteLater()
        self.favorite_buttons.clear()

        if not self.favorite_apps:
            return

        center_x = self.width() // 2
        center_y = self.height() // 2
        radius = min(self.width(), self.height()) // 3
        
        # カテゴリ別にグループ化
        categories = {}
        for app in self.favorite_apps:
            category = IconSystem.get_app_category(app["name"])
            if category not in categories:
                categories[category] = []
            categories[category].append(app)
        
        # カテゴリ順にソートされたアプリリストを再構築（カテゴリ間にスペーシング追加）
        sorted_apps = []
        category_positions = {}
        current_position = 0
        
        for category in sorted(categories.keys()):
            category_positions[category] = current_position
            sorted_apps.extend(categories[category])
            current_position += len(categories[category])
            # カテゴリ間のスペーシング（小さな隙間）
            if category != sorted(categories.keys())[-1]:  # 最後のカテゴリでない場合
                current_position += 0.3  # スペーシング調整
        
        total_positions = current_position
        
        position = 0
        for category in sorted(categories.keys()):
            for i, app in enumerate(categories[category]):
                angle = (2 * math.pi * position / total_positions) - (math.pi / 2)
                x = center_x + (radius * math.cos(angle)) - 45  # ボタンサイズ調整
                y = center_y + (radius * math.sin(angle)) - 45

                # アプリ情報を取得
                app_info = IconSystem.get_app_info(app["name"])
                
                btn = ModernButton(app_info, self)
                btn.app_command = app["command"]
                btn.clicked.connect(self.handle_button_click)
                btn.move(int(x), int(y))
                
                # カテゴリに応じたスタイルを適用
                btn.setStyleSheet(btn.get_button_style())

                btn.show()
                btn.raise_()  # ボタンを最前面に
                self.favorite_buttons.append(btn)
                
                position += 1
            
            # カテゴリ間のスペーシング
            if category != sorted(categories.keys())[-1]:
                position += 0.3

    def paintEvent(self, event):
        """モダンな背景描画"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # 背景グラデーション
        gradient = QRadialGradient(self.width()/2, self.height()/2, self.width()/2)
        gradient.setColorAt(0.0, QColor(30, 40, 60, 220))
        gradient.setColorAt(0.7, QColor(20, 25, 35, 240))
        gradient.setColorAt(1.0, QColor(10, 15, 25, 250))
        
        painter.setBrush(QBrush(gradient))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRect(self.rect())
        
        # 中央の装飾的な円
        center_x = self.width() // 2
        center_y = self.height() // 2
        
        # 外側の薄い円
        painter.setPen(QPen(QColor(255, 255, 255, 30), 2))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        outer_radius = min(self.width(), self.height()) // 2.5
        painter.drawEllipse(int(center_x - outer_radius), int(center_y - outer_radius),
                          int(outer_radius * 2), int(outer_radius * 2))
        
        # 内側のアクセント円
        painter.setPen(QPen(QColor(102, 126, 234, 80), 1))
        inner_radius = min(self.width(), self.height()) // 4
        painter.drawEllipse(int(center_x - inner_radius), int(center_y - inner_radius),
                          int(inner_radius * 2), int(inner_radius * 2))
        
        # 中央のドット
        painter.setBrush(QBrush(QColor(102, 126, 234, 150)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(int(center_x - 4), int(center_y - 4), 8, 8)

    def handle_button_click(self):
        button = self.sender()
        if hasattr(button, "app_command") and button.app_command:
            self.launch_app(button.app_command)

    def launch_app(self, command):
        """アプリ起動機能（改善版：アニメーション付きフィードバック）"""
        button = self.sender()
        
        # 起動開始の視覚的フィードバック
        if hasattr(button, 'original_text'):
            button.original_text = button.text()
        else:
            button.original_text = button.text()
        
        # 起動アニメーション開始
        self.start_launch_animation(button)
        
        try:
            if command.startswith("open "):
                command = f'open {shlex.quote(command[5:])}'
                result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
            else:
                result = subprocess.run(command.split(), check=True, capture_output=True, text=True)
                
            # 成功アニメーション
            self.show_success_animation(button)
            self.show_launch_feedback("success", f"アプリを起動しました")
            
            # 最近使用したアプリに追加
            self.add_to_recent_apps(command)
            
        except subprocess.CalledProcessError as e:
            self.show_error_animation(button)
            self.show_launch_feedback("error", f"起動に失敗: {e}")
            print(f"アプリの起動に失敗しました: {e}")
        except Exception as e:
            self.show_error_animation(button)
            self.show_launch_feedback("error", f"エラー: {e}")
            print(f"アプリの起動に失敗しました: {e}")
        finally:
            # 2秒後に元の状態に戻す
            QTimer.singleShot(2000, lambda: self.reset_button_state(button))
    
    def start_launch_animation(self, button):
        """起動時のアニメーション開始"""
        button.setText("🚀 起動中...")
        button.setEnabled(False)
        
        # 回転アニメーション
        self.rotation_animation = QPropertyAnimation(button, b"rotation")
        self.rotation_animation.setDuration(1000)
        self.rotation_animation.setStartValue(0)
        self.rotation_animation.setEndValue(360)
        self.rotation_animation.setLoopCount(-1)  # 無限ループ
        self.rotation_animation.start()
        
        # パルスアニメーション
        if hasattr(button, 'scale'):
            self.pulse_animation = QPropertyAnimation(button, b"scale")
            self.pulse_animation.setDuration(600)
            self.pulse_animation.setStartValue(1.0)
            self.pulse_animation.setEndValue(1.2)
            self.pulse_animation.setEasingCurve(QEasingCurve.Type.InOutSine)
            self.pulse_animation.setLoopCount(-1)  # 無限ループ
            self.pulse_animation.start()
    
    def show_success_animation(self, button):
        """成功時のアニメーション"""
        # 既存のアニメーションを停止
        if hasattr(self, 'rotation_animation'):
            self.rotation_animation.stop()
        if hasattr(self, 'pulse_animation'):
            self.pulse_animation.stop()
        
        button.setText("✅ 起動完了")
        
        # バウンスアニメーション
        if hasattr(button, 'scale'):
            self.success_animation = QPropertyAnimation(button, b"scale")
            self.success_animation.setDuration(400)
            self.success_animation.setStartValue(1.2)
            self.success_animation.setEndValue(1.0)
            self.success_animation.setEasingCurve(QEasingCurve.Type.OutBounce)
            self.success_animation.start()
        
        # 色の変化アニメーション
        button.setStyleSheet(button.styleSheet() + """
            ModernButton {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 rgba(76, 175, 80, 0.9), stop: 1 rgba(56, 142, 60, 0.9));
                border: 2px solid rgba(76, 175, 80, 0.8);
            }
        """)
    
    def show_error_animation(self, button):
        """エラー時のアニメーション"""
        # 既存のアニメーションを停止
        if hasattr(self, 'rotation_animation'):
            self.rotation_animation.stop()
        if hasattr(self, 'pulse_animation'):
            self.pulse_animation.stop()
        
        button.setText("❌ 起動失敗")
        
        # シェイクアニメーション
        self.shake_animation = QPropertyAnimation(button, b"pos")
        self.shake_animation.setDuration(500)
        original_pos = button.pos()
        
        # シェイク効果のキーフレーム
        self.shake_animation.setKeyValueAt(0.0, original_pos)
        self.shake_animation.setKeyValueAt(0.2, original_pos + QSize(5, 0).toPoint())
        self.shake_animation.setKeyValueAt(0.4, original_pos - QSize(5, 0).toPoint())
        self.shake_animation.setKeyValueAt(0.6, original_pos + QSize(3, 0).toPoint())
        self.shake_animation.setKeyValueAt(0.8, original_pos - QSize(3, 0).toPoint())
        self.shake_animation.setKeyValueAt(1.0, original_pos)
        self.shake_animation.start()
        
        # 色の変化アニメーション
        button.setStyleSheet(button.styleSheet() + """
            ModernButton {
                background: qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1,
                    stop: 0 rgba(244, 67, 54, 0.9), stop: 1 rgba(211, 47, 47, 0.9));
                border: 2px solid rgba(244, 67, 54, 0.8);
            }
        """)
    
    def reset_button_state(self, button):
        """ボタンの状態をリセット（アニメーション付き）"""
        # すべてのアニメーションを停止
        animations_to_stop = ['rotation_animation', 'pulse_animation', 'success_animation', 'shake_animation']
        for anim_name in animations_to_stop:
            if hasattr(self, anim_name):
                getattr(self, anim_name).stop()
        
        # 元のテキストとスタイルに戻す
        if hasattr(button, 'original_text'):
            button.setText(button.original_text)
        
        # 元のスタイルに戻すフェードアニメーション
        self.restore_animation = QPropertyAnimation(button, b"windowOpacity")
        self.restore_animation.setDuration(300)
        self.restore_animation.setStartValue(0.7)
        self.restore_animation.setEndValue(1.0)
        self.restore_animation.finished.connect(lambda: self.finalize_button_reset(button))
        self.restore_animation.start()
    
    def finalize_button_reset(self, button):
        """ボタンリセットの最終処理"""
        button.setEnabled(True)
        
        # 元のスタイルに戻す
        button.setStyleSheet(button.get_button_style())
        
        # スケールをリセット
        if hasattr(button, 'scale'):
            button.scale = 1.0
    
    def show_launch_feedback(self, status, message):
        """起動フィードバックを表示"""
        # 簡易的なフィードバック（ウィンドウタイトルに表示）
        original_title = self.windowTitle()
        
        if status == "success":
            self.setWindowTitle(f"✅ {message}")
        else:
            self.setWindowTitle(f"❌ {message}")
            
        QTimer.singleShot(2000, lambda: self.setWindowTitle(original_title))
    
    def add_to_recent_apps(self, command):
        """最近使用したアプリに追加"""
        if not hasattr(self, 'recent_apps'):
            self.recent_apps = []
            
        # 既存の同じコマンドを削除
        self.recent_apps = [app for app in self.recent_apps if app != command]
        
        # 先頭に追加
        self.recent_apps.insert(0, command)
        
        # 最大10個まで保持
        self.recent_apps = self.recent_apps[:10]

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # ボタンの位置を調整
        self.settings_button.move(20, 20)
        
        # 円形ボタンレイアウトを更新（少し遅延させる）
        QTimer.singleShot(100, self.create_circle_buttons)

    def mousePressEvent(self, event):
        """ウィンドウドラッグ機能"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        """ウィンドウドラッグ機能"""
        if event.buttons() == Qt.MouseButton.LeftButton and hasattr(self, 'drag_position'):
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()
    
    def showEvent(self, event):
        """ウィンドウ表示時の初期設定"""
        super().showEvent(event)
        # ウィンドウが完全に表示された後にボタンを作成
        QTimer.singleShot(50, self.create_circle_buttons)
    

def main():
    """Entry point for the Pi Menu application."""
    app = QApplication(sys.argv)
    ex = PiMenu()
    ex.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()