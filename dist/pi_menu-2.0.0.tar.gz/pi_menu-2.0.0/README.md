# Pi Menu - Modern Edition

Modern circular application launcher for macOS with Glassmorphism UI

## Features

### Design
- **Glassmorphism UI** - Modern transparent design
- **Smooth animations** - Enhanced user experience
- **Category-based colors** - Intuitive color coding
- **Modern icons** - 48+ app icons with automatic recognition

### Functionality
- Circular launcher with favorite apps
- Drag and drop interface
- Automatic app discovery
- Settings dialog with search and filter

## Installation

### Requirements
- Python 3.8+
- PyQt6

### Install
```bash
# Install dependencies
pip install PyQt6

# Or using uv
uv sync
```

### Run
```bash
# Direct execution
python pi_menu/main.py

# Or using installer
./run_pi_menu.sh
```

## Design Comparison

### Before (Original)
- Basic circular design
- Simple animations
- Limited color scheme

### After (Modern Edition)
- Modern Glassmorphism
- Smooth animations
- Rich color palette
- Enhanced visual effects

## Technical Details

- **Framework**: PyQt6
- **Design System**: Glassmorphism + Modern UI
- **Animations**: QPropertyAnimation
- **Effects**: QGraphicsDropShadowEffect
- **Layout**: Circular positioning

## Project Structure
```
pi_menu/
   pi_menu/
      main.py          # Main application
      main_original.py # Original version backup
      __init__.py
   config.json         # Configuration file
   README.md
   pyproject.toml
```

## Configuration

`config.json` contains app settings:
- App list
- Launch commands
- Icon mappings
- Favorite status

## Usage

1. Launch the application
2. Use settings gear to configure favorite apps
3. Click icons to launch applications
4. Drag window to move
5. Enjoy the modern circular interface

## Future Plans

- [ ] Cloud sync for settings
- [ ] Custom themes
- [ ] Keyboard shortcuts
- [ ] Widget support
- [ ] Multi-monitor support

---

**Author**: kenta_d  
**Version**: 2.0 - Modern Edition  
**License**: MIT License