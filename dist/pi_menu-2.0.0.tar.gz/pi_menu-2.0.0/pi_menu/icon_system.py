"""
Pi Menu アイコンシステム
アプリケーション名に基づいて適切なアイコンと色を自動選択
"""

import re
import os
from pathlib import Path
from typing import Tuple, Dict, Optional
from PyQt6.QtGui import QPixmap, QIcon, QPainter
from PyQt6.QtSvg import QSvgRenderer
from PyQt6.QtCore import QSize, Qt

class IconSystem:
    """アプリケーション名からアイコンと色を決定するシステム"""
    
    # アプリ名パターンとアイコンのマッピング
    ICON_PATTERNS = {
        # 開発系
        r'(visual studio|vs code|code)': '👨‍💻',
        r'(xcode)': '🔨',
        r'(cursor|windsurf)': '⚡',
        r'(zed)': '⚡',
        r'(jetbrains|toolbox)': '🧰',
        r'(sublime|atom|vim|emacs)': '📝',
        r'(git|github desktop)': '🐙',
        r'(postman|insomnia)': '🔧',
        r'(sourcetree|tower)': '🌳',
        
        # ブラウザ系
        r'(chrome|google chrome)': '🌐',
        r'(safari)': '🧭',
        r'(firefox)': '🦊',
        r'(arc)': '🌈',
        
        # 通信系
        r'(discord)': '💬',
        r'(zoom)': '📹',
        r'(teams|microsoft teams)': '👥',
        r'(outlook)': '📧',
        
        # クリエイティブ系
        r'(imovie)': '🎬',
        r'(garageband)': '🎵',
        r'(keynote)': '📊',
        r'(pages)': '📝',
        r'(numbers)': '📈',
        
        # ユーティリティ系
        r'(raycast)': '🚀',
        r'(commander|finder)': '📁',
        r'(dropbox)': '📦',
        r'(onedrive|google drive)': '☁️',
        r'(defender|security)': '🛡️',
        
        # ドキュメント系
        r'(notion)': '📋',
        r'(obsidian)': '🧠',
        r'(kindle|amazon kindle)': '📚',
        r'(upnote)': '📝',
        
        # Google系
        r'(google docs)': '📝',
        r'(google sheets)': '📊',
        r'(google slides)': '🎯',
        
        # Microsoft Office系
        r'(word|microsoft word)': '📄',
        r'(excel|microsoft excel)': '📊',
        r'(powerpoint|microsoft powerpoint)': '🎯',
        r'(onenote|microsoft onenote)': '📝',
        
        # デザイン系
        r'(photoshop|adobe photoshop)': '🎨',
        r'(illustrator|adobe illustrator)': '✏️',
        r'(figma)': '🎨',
        r'(sketch)': '📐',
        r'(canva)': '🖌️',
        r'(affinity|designer)': '🎭',
        
        # 教育系
        r'(anki)': '🎓',
        r'(duolingo)': '🌐',
        r'(khan academy)': '📚',
        r'(coursera|udemy)': '🎓',
        r'(moodle)': '📖',
        
        # ゲーム系
        r'(steam)': '🎮',
        r'(minecraft)': '🟫',
        r'(epic games)': '🎯',
        r'(battle.net|blizzard)': '⚔️',
        r'(origin|ea)': '🎮',
        
        # 金融系
        r'(money forward|moneytree)': '💰',
        r'(bank|banking)': '🏦',
        r'(crypto|bitcoin|coinbase)': '₿',
        r'(paypal|venmo)': '💳',
        r'(quicken|mint)': '📊',
        
        # その他
        r'(docker)': '🐳',
        r'(chatgpt)': '🤖',
        r'(perplexity)': '🔍',
        r'(claude)': '🧠',
        r'(devtoys)': '🔧',
        r'(iterm|terminal)': '⌨️',
        r'(pgadmin)': '🗄️',
        r'(karabiner)': '⌨️',
        r'(logi)': '🖱️',
        r'(calendar|notion calendar)': '📅',
        r'(github)': '🐙',
        r'(anaconda)': '🐍',
        r'(hhkb)': '⌨️',
        r'(weather|forecast)': '🌤️',
        r'(music|spotify|apple music)': '🎵',
        r'(vlc|media player)': '🎬',
    }
    
    # カテゴリ別の色定義
    CATEGORY_COLORS = {
        'development': ('rgba(76, 175, 80, 0.8)', 'rgba(56, 142, 60, 1.0)'),    # Green
        'browser': ('rgba(33, 150, 243, 0.8)', 'rgba(25, 118, 210, 1.0)'),      # Blue
        'communication': ('rgba(156, 39, 176, 0.8)', 'rgba(123, 31, 162, 1.0)'), # Purple
        'creative': ('rgba(255, 152, 0, 0.8)', 'rgba(230, 126, 34, 1.0)'),      # Orange
        'utility': ('rgba(96, 125, 139, 0.8)', 'rgba(69, 90, 100, 1.0)'),       # Blue Grey
        'document': ('rgba(63, 81, 181, 0.8)', 'rgba(48, 63, 159, 1.0)'),       # Indigo
        'google': ('rgba(244, 67, 54, 0.8)', 'rgba(211, 47, 47, 1.0)'),         # Red
        'microsoft': ('rgba(0, 150, 136, 0.8)', 'rgba(0, 121, 107, 1.0)'),      # Teal
        'ai': ('rgba(255, 87, 34, 0.8)', 'rgba(230, 74, 25, 1.0)'),             # Deep Orange
        'media': ('rgba(233, 30, 99, 0.8)', 'rgba(194, 24, 91, 1.0)'),          # Pink
        'system': ('rgba(121, 85, 72, 0.8)', 'rgba(93, 64, 55, 1.0)'),          # Brown
        'design': ('rgba(233, 30, 99, 0.8)', 'rgba(194, 24, 91, 1.0)'),         # Pink
        'education': ('rgba(76, 175, 80, 0.8)', 'rgba(56, 142, 60, 1.0)'),      # Light Green
        'games': ('rgba(255, 193, 7, 0.8)', 'rgba(255, 160, 0, 1.0)'),          # Amber
        'finance': ('rgba(0, 150, 136, 0.8)', 'rgba(0, 121, 107, 1.0)'),        # Teal
        'music': ('rgba(156, 39, 176, 0.8)', 'rgba(123, 31, 162, 1.0)'),        # Deep Purple
        'weather': ('rgba(33, 150, 243, 0.8)', 'rgba(25, 118, 210, 1.0)'),      # Light Blue
        'default': ('rgba(102, 126, 234, 0.8)', 'rgba(118, 75, 162, 0.8)')      # Default gradient
    }
    
    # アプリ名とカテゴリのマッピング
    CATEGORY_PATTERNS = {
        'development': [r'(visual studio|vs code|code|xcode|cursor|windsurf|zed|jetbrains|toolbox|docker|github|anaconda|iterm|terminal|devtoys|pgadmin|sublime|atom|vim|emacs|postman|insomnia|sourcetree|tower)'],
        'browser': [r'(chrome|safari|firefox|arc)'],
        'communication': [r'(discord|zoom|teams|outlook)'],
        'creative': [r'(imovie|garageband|keynote|pages|numbers)'],
        'utility': [r'(raycast|commander|finder|dropbox|onedrive|google drive|defender|karabiner|logi|hhkb)'],
        'document': [r'(notion|obsidian|kindle|upnote)'],
        'google': [r'(google docs|google sheets|google slides|google drive)'],
        'microsoft': [r'(word|excel|powerpoint|onenote|teams|outlook|onedrive)'],
        'ai': [r'(chatgpt|perplexity|claude)'],
        'media': [r'(imovie|garageband|vlc|media player)'],
        'system': [r'(defender|karabiner|logi|hhkb)'],
        'design': [r'(photoshop|illustrator|figma|sketch|canva|affinity|designer)'],
        'education': [r'(anki|duolingo|khan academy|coursera|udemy|moodle)'],
        'games': [r'(steam|minecraft|epic games|battle.net|blizzard|origin|ea)'],
        'finance': [r'(money forward|moneytree|bank|banking|crypto|bitcoin|coinbase|paypal|venmo|quicken|mint)'],
        'music': [r'(music|spotify|apple music)'],
        'weather': [r'(weather|forecast)']
    }
    
    @classmethod
    def get_icon_file_path(cls, app_name: str) -> Optional[str]:
        """アプリ名から外部アイコンファイルのパスを取得"""
        base_path = Path(__file__).parent.parent / "icon_assets"
        
        # バンドルID形式の名前を試行
        bundle_names = [
            app_name.lower().replace(" ", "-"),
            app_name.lower().replace(" ", "."),
            app_name.lower().replace(" ", "_")
        ]
        
        # 検索順序: custom -> svg -> png
        search_paths = [
            base_path / "custom",
            base_path / "svg", 
            base_path / "png"
        ]
        
        extensions = ['.svg', '.png', '.jpg', '.jpeg']
        
        for search_path in search_paths:
            if not search_path.exists():
                continue
                
            for bundle_name in bundle_names:
                for ext in extensions:
                    icon_path = search_path / f"{bundle_name}{ext}"
                    if icon_path.exists():
                        return str(icon_path)
        
        return None
    
    @classmethod
    def get_app_icon(cls, app_name: str) -> str:
        """アプリ名からアイコンを取得（外部ファイル優先、なければ分かりやすいデフォルト）"""
        # 外部アイコンファイルを最初に確認
        icon_file = cls.get_icon_file_path(app_name)
        if icon_file:
            return f"file://{icon_file}"
            
        app_name_lower = app_name.lower()
        
        for pattern, icon in cls.ICON_PATTERNS.items():
            if re.search(pattern, app_name_lower):
                return icon
        
        # デフォルトアイコン（アプリ名の最初の文字 or 汎用アイコン）
        if app_name:
            # 英数字ならその文字、そうでなければ📦
            c = app_name[0].upper()
            if c.isalnum():
                return c
        
        return '📦'

    @classmethod
    def get_app_category(cls, app_name: str) -> str:
        """アプリ名からカテゴリを取得"""
        app_name_lower = app_name.lower()
        
        for category, patterns in cls.CATEGORY_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, app_name_lower):
                    return category
        
        return 'default'
    
    @classmethod
    def get_app_colors(cls, app_name: str) -> Tuple[str, str]:
        """アプリ名から色を取得（normal, hover）"""
        category = cls.get_app_category(app_name)
        return cls.CATEGORY_COLORS.get(category, cls.CATEGORY_COLORS['default'])
    
    @classmethod
    def get_display_name(cls, app_name: str, max_length: int = 12) -> str:
        """表示用の短縮名を取得"""
        if len(app_name) <= max_length:
            return app_name
        
        # 重要な単語を抽出
        important_words = ['VS', 'Code', 'Chrome', 'Safari', 'Firefox', 'Teams', 'Word', 'Excel']
        
        for word in important_words:
            if word.lower() in app_name.lower():
                return word
        
        # スペースで分割して最初の単語を使用
        first_word = app_name.split()[0]
        if len(first_word) <= max_length:
            return first_word
        
        # 文字数制限で切り詰め
        return app_name[:max_length-1] + '…'

    @classmethod
    def load_external_icon(cls, icon_path: str, size: QSize = QSize(32, 32)) -> QIcon:
        """外部アイコンファイルを読み込み"""
        if not os.path.exists(icon_path):
            return QIcon()
            
        if icon_path.endswith('.svg'):
            # SVGファイルの処理
            renderer = QSvgRenderer(icon_path)
            pixmap = QPixmap(size)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            renderer.render(painter)
            painter.end()
            return QIcon(pixmap)
        else:
            # PNG/JPGファイルの処理
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                return QIcon(pixmap.scaled(size))
                
        return QIcon()
    
    @classmethod
    def get_app_info(cls, app_name: str) -> Dict[str, str]:
        """アプリの完全な情報を取得（カテゴリdefault時は日本語で'その他'も返す）"""
        icon = cls.get_app_icon(app_name)
        icon_file_path = None
        
        if icon.startswith("file://"):
            icon_file_path = icon[7:]  # "file://"を除去
            
        category = cls.get_app_category(app_name)
        category_jp = category if category != 'default' else 'その他'
        
        return {
            'icon': icon,
            'icon_file_path': icon_file_path,
            'display_name': cls.get_display_name(app_name),
            'category': category_jp,
            'colors': cls.get_app_colors(app_name),
            'full_name': app_name
        }